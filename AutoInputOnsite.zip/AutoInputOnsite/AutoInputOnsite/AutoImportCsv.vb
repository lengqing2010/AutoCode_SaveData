Option Explicit On
Option Strict On

Imports System.ComponentModel
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading.Thread

Public Class AutoImportCsv


    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
Public Shared Function FindWindow(ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function FindWindowEx( _
        ByVal parentHandle As IntPtr, _
        ByVal childAfter As IntPtr, _
        ByVal lclassName As String, _
        ByVal windowTitle As String) As IntPtr
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function SendMessage( _
        ByVal hWnd As IntPtr, _
        ByVal Msg As Integer, _
        ByVal wParam As Integer, _
        ByVal lParam As StringBuilder) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function IsWindowVisible( _
        ByVal hWnd As IntPtr) As Boolean
    End Function

    Private Enum WM As Integer
        SETTEXT = &HC
    End Enum

    Private Enum BM As Integer
        CLICK = &HF5
    End Enum

    Private WithEvents BackgroundWorker As New BackgroundWorker

    Dim Ie As New SHDocVw.InternetExplorer

    Private Sub AutoImportCsv_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        Ie.Quit()
    End Sub

    Private Sub AutoImportCsv_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Ie.Quit()
    End Sub

    Private Sub AutoImportCsv_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Ie = CreateObject("InternetExplorer.Application")
        'Dim uri As System.Uri = New Uri("http://bpn-ap-01d/ons/mit/Scripts/midasiSinkiNyuuryoku.asp?strMitKbn=&strServerName=&strBpnFlg=1&datNoCacheDummy=2018%2F12%2F26+16%3A07%3A46")

        'Dim myUri As UriBuilder = New UriBuilder("http://bpn-ap-01d/ons/mit/Scripts/midasiSinkiNyuuryoku.asp?strMitKbn=&strServerName=&strBpnFlg=1&datNoCacheDummy=2018%2F12%2F26+16%3A07%3A46")
        'myUri.UserName = "china\shil2"
        'myUri.Password = "asdf\@123"
        'myUri.Host = "http://bpn-ap-01d"



        Dim authHeader As String = "Authorization: Basic " + Convert.ToBase64String(System.Text.UnicodeEncoding.UTF8.GetBytes(String.Format("{0}:{1}", "china\shil2", "asdf\@123"))) + "\r\n"
        Dim url As String = _
            "http://ons-ap-01d/ONS/top/scripts/Sougou_Menu.asp"
        Ie.Navigate(url, , , , )
        Ie.Visible = True

        WaitComplete(Ie)

        GetElementBy(Ie, "", "input", "value", "OnSite�p�X���[�h���͂�").click()
        WaitComplete(Ie)

        'OnSite�p�X���[�h����
        GetElementBy(Ie, "", "input", "name", "strPassWord").innerText = "kaihatu"
        GetElementBy(Ie, "", "input", "value", "���O�I��").click()
        WaitComplete(Ie)

        '�Ɩ��ʑ������j���[
        GetElementBy(Ie, "SubHeader", "a", "innertext", "[����]").click()
        WaitComplete(Ie)

        '���̖���
        GetElementBy(Ie, "Main", "input", "value", "���̖���").click()
        WaitComplete(Ie)
        System.Threading.Thread.Sleep(1500)


        '�V�K���ς���
SinkiMiturori:

        Dim ShellWindows As New SHDocVw.ShellWindows
        For Each childIe As SHDocVw.InternetExplorer In ShellWindows
            Dim filename As String = System.IO.Path.GetFileNameWithoutExtension(Ie.FullName).ToLower()
            If filename = "iexplore" Then
                If CType(childIe, SHDocVw.InternetExplorer).LocationURL.Contains("mitSearch.asp") Then
                    If CType(childIe.Document, mshtml.HTMLDocument).title = "OnSite" Then
                        If CType(childIe.Document, mshtml.HTMLDocument).url.Contains("mitSearch.asp") Then
                            WaitComplete(childIe)
                            System.Threading.Thread.Sleep(500)
                            Try


                                GetElementBy(childIe, "", "input", "value", "�V�K����").click()
                            Catch ex As Exception
                                GoTo SinkiMiturori
                            End Try
                            'WaitComplete(childIe)
                        End If
                    End If
                End If
            End If
        Next

        System.Threading.Thread.Sleep(500)
        WaitComplete(Ie)
        '���ό��o����
        GetElementBy(Ie, "fraMitBody", "input", "name", "strJgyCdText").innerText = "TPP5"
        GetElementBy(Ie, "fraMitBody", "input", "name", "strTokMeiText").innerText = "420159"
        GetElementBy(Ie, "fraMitBody", "select", "name", "aryKijyunSyouhinBunrui").setAttribute("value", "A0001,�T�b�V,L90000")


        GetElementBy(Ie, "fraMitBody", "input", "name", "btnUtiwake").click()
        System.Threading.Thread.Sleep(500)
        WaitComplete(Ie)
        System.Threading.Thread.Sleep(500)
        WaitComplete(Ie)
        System.Threading.Thread.Sleep(500)
        WaitComplete(Ie)

        '���ϓ������
WaitNY:
        Try
            Dim ele As mshtml.IHTMLElement = GetElementBy(Ie, "fraMitBody", "DIV", "classname", "ttl")
            If ele.innerText <> "���ϓ������" Then
                GoTo WaitNY
            End If
            GetElementBy(Ie, "fraMitBody", "input", "value", "CSV�捞").click()
        Catch ex As Exception
            GoTo WaitNY
        End Try


        WaitComplete(Ie)
        System.Threading.Thread.Sleep(1500)
        Me.BackgroundWorker.RunWorkerAsync(Application.ExecutablePath)
        For Each childIe As SHDocVw.InternetExplorer In ShellWindows
            Dim filename As String = System.IO.Path.GetFileNameWithoutExtension(Ie.FullName).ToLower()
            If filename = "iexplore" Then
                If CType(childIe, SHDocVw.InternetExplorer).LocationURL.Contains("fileYomikomiSiji.asp") Then
                    If CType(childIe.Document, mshtml.HTMLDocument).title = "OnSite" Then
                        If CType(childIe.Document, mshtml.HTMLDocument).url.Contains("fileYomikomiSiji.asp") Then
                            WaitComplete(childIe)
                            System.Threading.Thread.Sleep(500)
                            Try


                                System.Threading.Thread.Sleep(500)
                                GetElementBy(childIe, "", "input", "value", "�Q�@��").click()


                                System.Threading.Thread.Sleep(500)
                            Catch ex As Exception
                                GoTo SinkiMiturori
                            End Try
                            'WaitComplete(childIe)
                        End If
                    End If
                End If

            End If
        Next




    End Sub

    Private Sub BackgroundWorker_DoWork(ByVal sender As Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker.DoWork
        Dim FileName As String = DirectCast(e.Argument, String)
        Dim hWnd As IntPtr
        Do While hWnd = IntPtr.Zero
            hWnd = FindWindow("#32770", "�A�b�v���[�h����t�@�C���̑I��")
            Sleep(1)
        Loop
        Dim hComboBoxEx As IntPtr = FindWindowEx(hWnd, IntPtr.Zero, "ComboBoxEx32", String.Empty)
        Dim hComboBox As IntPtr = FindWindowEx(hComboBoxEx, IntPtr.Zero, "ComboBox", String.Empty)
        Dim hEdit As IntPtr = FindWindowEx(hComboBox, IntPtr.Zero, "Edit", String.Empty)
        Do Until IsWindowVisible(hEdit)
            Sleep(1)
        Loop
        SendMessage(hEdit, WM.SETTEXT, 0, New StringBuilder(FileName))
        Dim hButton As IntPtr = FindWindowEx(hWnd, IntPtr.Zero, "Button", "�J��(&O)")
        SendMessage(hButton, BM.CLICK, 0, Nothing)
    End Sub


    Sub WaitComplete(ByRef webApp As SHDocVw.InternetExplorer)
        Do Until webApp.ReadyState = WebBrowserReadyState.Complete AndAlso Not webApp.Busy
            System.Windows.Forms.Application.DoEvents()
            System.Threading.Thread.Sleep(500)
        Loop
        System.Threading.Thread.Sleep(100)
    End Sub


    Public Function GetElementBy(ByRef webApp As SHDocVw.InternetExplorer, ByVal fraName As String, ByVal tagName As String, ByVal keyName As String, ByVal keyTxt As String) As mshtml.IHTMLElement

        Dim Doc As mshtml.HTMLDocument = CType(webApp.Document, mshtml.HTMLDocument)
        Dim eles As mshtml.IHTMLElementCollection

        If fraName = "" Then
            eles = Doc.getElementsByTagName(tagName)
        Else
            Dim fra As mshtml.HTMLWindow2 = GetFrameByName(webApp, fraName)
            Doc = CType(fra.document, mshtml.HTMLDocument)
            eles = Doc.getElementsByTagName(tagName)
        End If


        For Each ele As mshtml.IHTMLElement In eles
            Try

                If keyName = "innertext" Then
                    If ele.innerText = keyTxt Then
                        Return ele
                    End If
                Else
                    If ele.getAttribute(keyName).ToString = keyTxt Then
                        Return ele
                    End If
                End If

            Catch ex As Exception

            End Try

        Next

        Return Nothing

    End Function


    Public Function GetFrameByName(ByRef webApp As SHDocVw.InternetExplorer, ByVal name As String) As mshtml.HTMLWindow2
        Dim Doc As mshtml.HTMLDocument = CType(webApp.Document, mshtml.HTMLDocument)
        Dim length As Integer = Doc.frames.length
        Dim frames As mshtml.FramesCollection = Doc.frames
        Dim i As Object
        For i = 0 To length - 1
            Dim frm As mshtml.HTMLWindow2 = CType(frames.item(i), mshtml.HTMLWindow2)
            If frm.name = name Then
                Return frm
            End If
        Next

        For i = 0 To length - 1
            Dim frm As mshtml.HTMLWindow2 = CType(frames.item(i), mshtml.HTMLWindow2)
            Dim wd As Object = GetFrameByName(frm, name)
            If wd IsNot Nothing Then
                Return CType(wd, mshtml.HTMLWindow2)
            End If
        Next

        Return Nothing
    End Function

    Public Function GetFrameByName(ByRef webApp As mshtml.HTMLWindow2, ByVal name As String) As mshtml.HTMLWindow2
        Dim Doc As mshtml.HTMLDocument = CType(webApp.document, mshtml.HTMLDocument)
        Dim length As Integer = Doc.frames.length
        Dim frames As mshtml.FramesCollection = Doc.frames
        Dim i As Object
        For i = 0 To length - 1
            Dim frm As mshtml.HTMLWindow2 = CType(frames.item(i), mshtml.HTMLWindow2)
            If frm.name = name Then
                Return frm
            End If
        Next

        For i = 0 To length - 1
            Dim frm As mshtml.HTMLWindow2 = CType(frames.item(i), mshtml.HTMLWindow2)
            Dim wd As Object = GetFrameByName(frm, name)
            If wd IsNot Nothing Then
                Return CType(wd, mshtml.HTMLWindow2)
            End If
        Next

        Return Nothing

    End Function

End Class